package com.portfolio.sebamazu;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SebamazuApplication {

	public static void main(String[] args) {
		SpringApplication.run(SebamazuApplication.class, args);
	}

}
