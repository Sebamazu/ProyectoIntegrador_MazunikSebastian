package com.portfolio.sebamazu;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SebamazuApplicationTests {

	@Test
	void contextLoads() {
	}

}
